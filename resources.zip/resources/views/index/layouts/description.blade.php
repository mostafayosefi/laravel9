
@if($name_nav == 'contact')

<p style="color: #000856; font-size: 18px">
 لطفا تمام فیلدها را با زبان انگلیسی پر نمایید
 </p>
@endif
