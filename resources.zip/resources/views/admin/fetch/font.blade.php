<div class="elementor-icon-wrapper">
    <div class="elementor-icon">
    <i  aria-hidden="true" class="fa  {{$value}}"  style="font-size:78px;color:#665CAC;"></i>
    </div>
    </div>
