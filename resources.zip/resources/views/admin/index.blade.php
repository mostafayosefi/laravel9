
@component('admin.layouts.content',[
    'title'=>'داشبورد',
    'tabTitle'=>'داشبورد',
    'breadcrumb'=>[
            ['title'=>'داشبورد', 'url' => route('admin.dashboard')]
    ]])



@slot('script')

@endslot
@endcomponent
